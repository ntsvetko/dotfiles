import static org.junit.Assert.assertEquals;
#parse("File Header.java")
public class ${NAME} {
  ${BODY}
}