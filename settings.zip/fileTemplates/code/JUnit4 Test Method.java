@org.junit.Test
public void test${NAME}() {
  ${BODY}
}