@org.junit.jupiter.api.Test
void test${NAME}() {
  ${BODY}
}